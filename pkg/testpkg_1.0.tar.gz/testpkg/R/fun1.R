fun1 <-
function(x) rnorm(x)
