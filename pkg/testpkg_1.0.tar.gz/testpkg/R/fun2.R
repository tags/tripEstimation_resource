fun2 <-
function(y) fun1(y) + 10
